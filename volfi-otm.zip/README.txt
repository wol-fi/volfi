vol-fi OTM kernel
=================

This zip contains a small header-only C++17 implementation of a domain-specialized
Black-Scholes implied-variance kernel.

It solves the projected OTM-call problem

    h = |log(K/F)| > 0
    w = sigma^2 T
    w = Q_h(c_otm)

where c_otm is the normalised out-of-the-money call price. The kernel uses a
rational seed for implied variance followed by one Halley refinement.

Scope
-----

The implementation is currently calibrated/tested for the OTM benchmark grid

    v     in {0.01, 0.05, 0.10, ..., 2.00}
    Delta in {0.55, 0.70, 0.80, 0.95}

It is a research prototype, not a global replacement for LetsBeRational.
No LetsBeRational source or binary is included in this archive.

Files
-----

    include/volfi/volfi.hpp        header-only implementation
    tests/test_otm_grid.cpp        accuracy check on the OTM grid
    bench/bench_otm_grid.cpp       speed/accuracy benchmark on the OTM grid
    Makefile                       simple make-based build
    CMakeLists.txt                 CMake build file

Requirements
------------

A C++17 compiler is required. The Makefile defaults to clang++, but g++ also works.

Tested build style:

    clang++ or g++
    -std=c++17

Quick start with make
---------------------

Unzip the archive and enter the directory:

    unzip vol-fi-otm.zip
    cd vol-fi-otm

Build everything:

    make

Run the accuracy test:

    make test

Run the benchmark:

    make bench

Clean generated binaries:

    make clean

If clang++ is not available, use g++:

    make CXX=g++
    make test
    make bench

Quick start with CMake
----------------------

    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build
    ctest --test-dir build --output-on-failure
    ./build/bench_otm_grid

Using the header in your own code
---------------------------------

Add include/ to your compiler include path and include the header:

    #include <volfi/volfi.hpp>

Canonical OTM fast path:

    double h = std::abs(std::log(K / F));
    double w = volfi::implied_variance_otm(h, c_otm);
    double sigma = std::sqrt(w / T);

For an OTM call with K > F:

    double c_otm = C / (D * F);

where C is the undiscounted market call price multiplied by the discount convention
used in Black-Scholes, D is the discount factor, and F is the forward.

For an ITM call with K < F, first project exactly to the OTM side:

    double c = C / (D * F);
    double c_otm = 1.0 + (F / K) * (c - 1.0);
    double h = std::log(F / K);
    double w = volfi::implied_variance_otm(h, c_otm);
    double sigma = std::sqrt(w / T);

There is also a convenience wrapper:

    double w = volfi::implied_variance_call_normalised(k, c);

where

    k = log(K / F)
    c = C / (D * F)

Benchmark convention
--------------------

The bundled benchmark uses

    164 grid cases
    5000 repetitions per run
    9 timing runs

and reports mean/max errors plus nanoseconds per evaluation.

Recommended release build flags for benchmarking are the Makefile defaults:

    -O1 -march=native -ffp-contract=fast -fno-math-errno

These flags are intended for local speed testing. For portability, remove
-march=native.

Numerical notes
---------------

The OTM kernel returns total implied variance w = sigma^2 T. To obtain volatility,
use sigma = sqrt(w / T).

Inputs must satisfy

    h > 0
    0 < c_otm < 1

The ATM case h = 0 is not the target of this prototype.
