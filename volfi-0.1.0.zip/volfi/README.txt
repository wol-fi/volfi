volfi v0.1.0 OTM kernel
========================

This archive contains a header-only C++17 implementation of a domain-specialized
Black-Scholes implied-variance kernel.

It solves the projected OTM-call problem

    h = |log(K/F)| > 0
    w = sigma^2 T
    w = Q_h(c_otm)

where c_otm is the normalised out-of-the-money call price. The kernel uses a
rational seed for implied variance followed by one Halley refinement.


Version
-------

This archive is volfi v0.1.0, the first public research prototype of the
OTM-projected implied-variance kernel.


Scope
-----

The implementation is currently calibrated/tested for the OTM benchmark grid

    v     in {0.01, 0.05, 0.10, ..., 2.00}
    Delta in {0.55, 0.70, 0.80, 0.95}

It is a research prototype, not a global replacement for LetsBeRational.
No LetsBeRational source or binary is included in this archive.


Files
-----

    include/volfi/volfi.hpp        header-only implementation
    tests/test_otm_grid.cpp        accuracy check on the OTM grid
    bench/bench_otm_grid.cpp       speed/accuracy benchmark on the OTM grid
    Makefile                       simple make-based build
    CMakeLists.txt                 CMake build file


Requirements
------------

A C++17 compiler is required. The Makefile defaults to clang++, but g++ also works.


Quick start with make
---------------------

Unzip the archive and enter the directory:

    unzip volfi-0.1.0.zip
    cd volfi

Build everything:

    make

Run the accuracy test:

    make test

Run the benchmark:

    make bench

Clean generated binaries:

    make clean

If clang++ is not available, use g++:

    make CXX=g++
    make test
    make bench


Quick start with CMake
----------------------

    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build
    ctest --test-dir build --output-on-failure
    ./build/bench_otm_grid


Using the header in your own code
---------------------------------

Add include/ to your compiler include path and include the header:

    #include <volfi/volfi.hpp>

Canonical OTM path:

    double h = std::abs(std::log(K / F));
    double w = volfi::implied_variance_otm(h, c_otm);
    double sigma = std::sqrt(w / T);

For an OTM call with K > F:

    double c_otm = C / (D * F);

For an ITM call with K < F, first project exactly to the OTM side:

    double c = C / (D * F);
    double c_otm = 1.0 + (F / K) * (c - 1.0);
    double h = std::log(F / K);
    double w = volfi::implied_variance_otm(h, c_otm);
    double sigma = std::sqrt(w / T);

There is also a convenience wrapper:

    double w = volfi::implied_variance_call_normalised(k, c);

where

    k = log(K / F)
    c = C / (D * F)


Using the precomputed context
-----------------------------

If many prices are inverted for the same h, precompute the h-dependent terms once:

    volfi::otm_context q(h);
    double w = volfi::implied_variance_otm(q, c_otm);

This removes repeated evaluation of h^2, exp(h/2), and exp(h) from the hot path.
The benchmark includes both the direct and precomputed variants.


Benchmark convention
--------------------

The bundled benchmark uses 5000 repetitions of the 164-case grid. Each timing run
therefore contains

    5000 * 164 = 820000

implied-volatility evaluations. It reports nanoseconds per evaluation.

Typical benchmark result for the packaged code in this environment:

    direct OTM kernel:        median 93.75 ns/eval
    precomputed OTM context:  median 89.97 ns/eval

The precomputed context is about 4% faster in this scalar benchmark.


License
-------

No license is included in this archive. Add a license before publishing if you want
to make reuse terms explicit.
