#ifndef VOLFI_VOLFI_HPP
#define VOLFI_VOLFI_HPP

#include <cmath>
#include <limits>

namespace volfi {

constexpr double is2=0.707106781186547524400844362104849039;
constexpr double inv2sr2pi=0.199471140200716338969973029967190934;
constexpr double zm=-1.3598702230721038;
constexpr double zs=1.4166096270741921;
constexpr double am=0.24945973608277752;
constexpr double as=0.16774924919318354;

struct otm_context {
 double h,h2,eh2,eh;
 explicit otm_context(double x):h(x),h2(x*x),eh2(std::exp(0.5*x)),eh(eh2*eh2){}
};

inline double phi_cdf(double x){return 0.5*std::erfc(-x*is2);}

inline double peval(double x,double b){return (((((((((1.928095365588689e-07*x+(2.8738951871609686e-06*b+1.0239510778581318e-05))*x+((-1.6587020181813017e-06*b+6.203196575312736e-05)*b+0.0001817143403100574))*x+(((-7.4231005582278686e-06*b+-4.7434023825114469e-05)*b+0.00060036123536945374)*b+0.00172719975565927))*x+((((1.0567878094183691e-05*b+-8.7595889889061085e-05)*b+-0.0004949154383191998)*b+0.0034403310794426101)*b+0.010331905825498495))*x+(((((-1.9368183094808922e-05*b+7.6646563984372751e-05)*b+-0.00039930678612073306)*b+-0.0018218430192540108)*b+0.015370839404664417)*b+0.043479946677951312))*x+((((((1.2519018710133167e-05*b+-0.00014521830420177783)*b+-0.0002955676243929211)*b+-0.0043239632259064187)*b+-0.0098433400572420088)*b+0.046190024665258275)*b+0.12954291859178019))*x+(((((((3.0183883955731128e-06*b+0.00010336661362327082)*b+0.00025309569970291546)*b+0.0030806312339209316)*b+0.006537694965122888)*b+0.028008058550339485)*b+0.17553065303457216)*b+0.3089820804860039))*x+((((((((-1.1532724232196645e-06*b+-8.1065274928071585e-06)*b+-0.00010280897236450426)*b+-0.0012323021962412153)*b+-0.0090347401647867566)*b+-0.051926898561902537)*b+-0.071919567939222315)*b+0.1861136545125075)*b+0.42246511376723694))*x+(((((((((6.9098382460275332e-08*b+1.2508405552169588e-06)*b+1.1564774935010624e-05)*b+1.0266448849237386e-05)*b+0.00034487495977462285)*b+0.0062006546766305917)*b+0.06318189536894557)*b+0.32404532148094944)*b+0.74544391675680632)*b+0.63842640478846868));}

inline double qeval(double x,double b){return 1+((((((((1.3748415080026832e-05*x+(1.6066265945916675e-05*b+-5.4824433241479342e-05))*x+((-6.9767853676724889e-05*b+-1.115097303727719e-05)*b+0.00019336855672253805))*x+(((0.0002008065541999754*b+0.00059768562033165294)*b+-0.0025616552372954016)*b+-0.0036830440132808936))*x+((((-1.8428554824465038e-05*b+-0.0020297382579821735)*b+-0.001811480465041264)*b+0.026607453051468402)*b+0.036601886863643712))*x+(((((-4.9766312111981792e-06*b+0.00028773310675475269)*b+0.0091098941218230589)*b+-0.0010002854264361052)*b+-0.12256220195937752)*b+-0.15911242967862133))*x+((((((9.0966380868924557e-06*b+-2.9110006370763886e-05)*b+-0.0013375768997232335)*b+-0.024656007691467689)*b+0.01472210755686533)*b+0.35969833135840668)*b+0.49529256336820693))*x+(((((((1.5213058910390487e-06*b+-3.0994488404267884e-05)*b+0.00011737147593139652)*b+0.0031164487255468665)*b+0.037461963095410271)*b+-0.044418502764698012)*b+-0.58561914140891247)*b+-0.78314638531498904))*x+((((((((-4.1072266956931891e-07*b+-2.731072500782028e-06)*b+0.00010018766817737612)*b+-0.00040234211600881711)*b+-0.0028627242835490441)*b+-0.037190417922966658)*b+0.030955531573721995)*b+0.62726327865187903)*b+0));}

inline double seed_otm(double h,double c){
 double z=std::log(c/(1-c));
 double a=h/(1+h);
 double x=(z-zm)/zs;
 double b=(a-am)/as;
 return peval(x,b)/qeval(x,b);
}

inline double black_otm_from_variance(double w,double h){
 double s=std::sqrt(w), u=-h/s;
 return phi_cdf(u+0.5*s)-std::exp(h)*phi_cdf(u-0.5*s);
}

inline double black_otm_from_variance(double w,const otm_context& q){
 double s=std::sqrt(w), u=-q.h/s;
 return phi_cdf(u+0.5*s)-q.eh*phi_cdf(u-0.5*s);
}

inline double implied_variance_otm(const otm_context& q,double c){
 double w=seed_otm(q.h,c);
 if(!(w>0)) w=1e-12;
 double s=std::sqrt(w), invs=1/s, invw=invs*invs, u=-q.h*invs, halfs=0.5*s;
 double r=phi_cdf(u+halfs)-q.eh*phi_cdf(u-halfs)-c;
 double d=inv2sr2pi*q.eh2*invs*std::exp(-0.125*w-0.5*q.h2*invw);
 double l1=(0.5*q.h2*invw-0.5)*invw-0.125;
 double wn=w-2*r/(2*d-r*l1);
 return ((wn>0)&&std::isfinite(wn))?wn:w;
}

inline double implied_variance_otm(double h,double c){
 otm_context q(h);
 return implied_variance_otm(q,c);
}

inline double implied_volatility_otm(const otm_context& q,double c,double t){
 return std::sqrt(implied_variance_otm(q,c)/t);
}

inline double implied_volatility_otm(double h,double c,double t){
 return std::sqrt(implied_variance_otm(h,c)/t);
}

inline double implied_variance_call_normalised(double k,double c){
 if(k>0) return implied_variance_otm(k,c);
 if(k<0) return implied_variance_otm(-k,1+std::exp(-k)*(c-1));
 return std::numeric_limits<double>::quiet_NaN();
}

inline double implied_volatility_call_normalised(double k,double c,double t){
 return std::sqrt(implied_variance_call_normalised(k,c)/t);
}

inline double implied_volatility_call(double f,double k,double d,double t,double price){
 double kk=std::log(k/f), c=price/(d*f);
 return implied_volatility_call_normalised(kk,c,t);
}

}

#endif
