volfi v0.1.4 precomputed OTM kernel
=====================================

This archive contains a header-only C++17 implementation of a domain-specialized
Black-Scholes implied-variance kernel.

It solves the projected OTM-call problem

    h = |log(K/F)| > 0
    w = sigma^2 T
    w = Q_h(c_otm)

where c_otm is the normalised out-of-the-money call price. The kernel uses a
piecewise rational seed for implied variance followed by one Halley refinement.

At the forward, the normalised-call wrapper uses the explicit ATM formula.


Version
-------

This archive is volfi v0.1.4. Relative to v0.1.3, it adds a narrow robustness
fallback: one extra Halley refinement in a small near-ATM/low-price transition
region. This preserves the precomputed fast path and fixes random tests with
both v and Delta sampled continuously.


Scope
-----

The implementation is currently calibrated/tested for

    v     in {0.01, 0.05, 0.10, ..., 2.00}
    Delta in [0.5, 0.99]

on the projected OTM side. The package includes tests for

    Delta in {0.55, 0.70, 0.80, 0.95}
    Delta in {0.52, 0.99}
    5000 random uniform Delta values in [0.5, 0.99]
    200000 random pairs with Delta in [0.5, 0.99] and v in [0.01, 2.0]
    the exact at-the-forward formula

It is a research prototype, not a global replacement for LetsBeRational.
No LetsBeRational source or binary is included in this archive.


Files
-----

    include/volfi/volfi.hpp        header-only implementation
    tests/test_otm_grid.cpp        accuracy check on the original OTM grid
    tests/test_edge_grid.cpp       accuracy check for Delta=0.52 and Delta=0.99
    tests/test_random_delta.cpp    random uniform Delta test on [0.5, 0.99]
    tests/test_atm.cpp             exact at-the-forward check
    bench/bench_otm_grid.cpp       precomputed-context benchmark on the OTM grid
    Makefile                       simple make-based build
    CMakeLists.txt                 CMake build file


Requirements
------------

A C++17 compiler is required. The Makefile defaults to clang++, but g++ also works.


Quick start with make
---------------------

Unzip the archive and enter the directory:

    unzip volfi-0.1.4-random-vdelta.zip
    cd volfi

Build everything:

    make

Run the accuracy tests:

    make test

Run the benchmark:

    make bench

Clean generated binaries:

    make clean

If clang++ is not available, use g++:

    make CXX=g++
    make test
    make bench


Quick start with CMake
----------------------

    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build
    ctest --test-dir build --output-on-failure
    ./build/bench_otm_grid


Using the header in your own code
---------------------------------

Add include/ to your compiler include path and include the header:

    #include <volfi/volfi.hpp>

Preferred precomputed OTM path:

    double h = std::abs(std::log(K / F));
    volfi::otm_context q(h);
    double w = volfi::implied_variance_otm(q, c_otm);
    double sigma = std::sqrt(w / T);

For an OTM call with K > F:

    double c_otm = C / (D * F);

For an ITM call with K < F, first project exactly to the OTM side:

    double c = C / (D * F);
    double c_otm = 1.0 + (F / K) * (c - 1.0);
    double h = std::log(F / K);
    volfi::otm_context q(h);
    double w = volfi::implied_variance_otm(q, c_otm);
    double sigma = std::sqrt(w / T);

There is also a convenience wrapper:

    double w = volfi::implied_variance_call_normalised(k, c);

where

    k = log(K / F)
    c = C / (D * F)

If k == 0, this wrapper uses the explicit ATM normal-quantile formula.


Precomputed context
-------------------

The precomputed context stores h-dependent quantities once and reuses them in
the hot path. It stores

    h, h^2, exp(h/2), exp(h)

and also precomputes the high-price branch coefficients of the rational seed.
This is useful when many prices are inverted on a fixed strike/moneyness grid.


Benchmark convention
--------------------

The benchmark uses 5000 repetitions of the 164-case original grid. Each timing
run therefore contains

    5000 * 164 = 820000

precomputed-context implied-variance evaluations. It reports nanoseconds per
implied-volatility evaluation, including the final square root in the benchmark
loop.


License
-------

No license is included in this archive. Add a license before publishing if you
want to make reuse terms explicit.
